package com.agrirakshak.backend.controller;

import com.agrirakshak.backend.dto.FarmerProfileDto;
import com.agrirakshak.backend.service.FarmerService;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/farmer")
@RequiredArgsConstructor
@CrossOrigin(origins = "http://localhost:5500")
public class FarmerController {

    private final FarmerService farmerService;

    @GetMapping("/profile")
    public FarmerProfileDto getProfile(Authentication authentication) {

        return farmerService.getProfile(authentication.getName());
    }

    @PutMapping("/profile")
    public FarmerProfileDto updateProfile(
            Authentication authentication,
            @RequestBody FarmerProfileDto dto) {

        return farmerService.updateProfile(
                authentication.getName(),
                dto
        );
    }
}