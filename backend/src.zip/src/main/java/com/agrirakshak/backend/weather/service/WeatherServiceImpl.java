package com.agrirakshak.backend.weather.service;

import com.agrirakshak.backend.weather.dto.WeatherResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.Map;

@Service
@RequiredArgsConstructor
public class WeatherServiceImpl implements WeatherService {

    @Value("${weather.api.key}")
    private String apiKey;

    private final RestTemplate restTemplate = new RestTemplate();

    @Override
    public WeatherResponse getWeather(String city) {

        String url =
                "https://api.openweathermap.org/data/2.5/weather?q="
                        + city
                        + "&appid="
                        + apiKey
                        + "&units=metric";

        Map<String, Object> response =
                restTemplate.getForObject(url, Map.class);

        Map<String, Object> main =
                (Map<String, Object>) response.get("main");

        Map<String, Object> wind =
                (Map<String, Object>) response.get("wind");

        Map<String, Object> weather =
                (Map<String, Object>) ((java.util.List<?>) response.get("weather")).get(0);

        return new WeatherResponse(
                city,
                ((Number) main.get("temp")).doubleValue(),
                ((Number) main.get("humidity")).intValue(),
                ((Number) wind.get("speed")).doubleValue(),
                weather.get("description").toString()
        );
    }
}