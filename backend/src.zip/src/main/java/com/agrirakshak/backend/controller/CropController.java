package com.agrirakshak.backend.controller;

import com.agrirakshak.backend.entity.Crop;
import com.agrirakshak.backend.service.CropService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/crops")
@RequiredArgsConstructor
@CrossOrigin(origins = "http://localhost:5500")
public class CropController {

    private final CropService cropService;

    @PostMapping
    public ResponseEntity<Crop> createCrop(@RequestBody Crop crop) {
        return new ResponseEntity<>(cropService.saveCrop(crop), HttpStatus.CREATED);
    }

    @GetMapping
    public ResponseEntity<List<Crop>> getAllCrops() {
        return ResponseEntity.ok(cropService.getAllCrops());
    }

    @GetMapping("/{id}")
    public ResponseEntity<Crop> getCropById(@PathVariable Long id) {
        return ResponseEntity.ok(cropService.getCropById(id));
    }

    @PutMapping("/{id}")
    public ResponseEntity<Crop> updateCrop(
            @PathVariable Long id,
            @RequestBody Crop crop) {

        return ResponseEntity.ok(cropService.updateCrop(id, crop));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteCrop(@PathVariable Long id) {

        cropService.deleteCrop(id);

        return ResponseEntity.ok("Crop deleted successfully.");
    }
}